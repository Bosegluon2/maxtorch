# 序列建模相关高阶模块 
from .blocks import TransformerEncoderBlock, TransformerDecoderBlock, LSTMBlock, GRUBlock 