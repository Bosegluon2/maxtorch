# maxtorch: 高阶PyTorch模块库 
from .vision import *
from .attention import *
from .sequence import *
from .generative import * 