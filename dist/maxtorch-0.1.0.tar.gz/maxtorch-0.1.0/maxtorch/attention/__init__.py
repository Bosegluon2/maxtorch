# 注意力机制相关高阶模块 
from .blocks import SqueezeExcitationBlock, CBAMBlock, SelfAttention2d, NonLocalBlock, ECABlock, GCBlock, CoordinateAttention, PerformerBlock